package com.example.konstantin.dadad;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.widget.Toast;

import com.example.kvlmjpeg.DisplayMode;
import com.example.kvlmjpeg.Mjpeg;
import com.example.kvlmjpeg.MjpegSurfaceView;
import com.example.kvlmjpeg.MjpegView;

import butterknife.BindView;
import butterknife.ButterKnife;

public class StreamActivity extends AppCompatActivity {
    @BindView(R.id.mjpegSurfaceView)
    MjpegView mjpegeView;
    String URL;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_stream);
        ButterKnife.bind(this);
        URL=getIntent().getStringExtra("ip");

    }

    private void loadStream(){
        Mjpeg.newInstance().open(URL, 5)
                .subscribe(
                        mjpegInputStream -> {
                            mjpegeView.setSource(mjpegInputStream);
                            mjpegeView.setDisplayMode(DisplayMode.BEST_FIT);
                            mjpegeView.showFps(true);
                        },
                        throwable -> {
                            Log.e(getClass().getSimpleName(), "mjpeg error", throwable);
                            Toast.makeText(this,"Error",Toast.LENGTH_SHORT).show();
                        }
                );
    }

    @Override
    protected void onResume() {
        super.onResume();
        loadStream();
    }

    @Override
    protected void onPause() {
        super.onPause();
        mjpegeView.stopPlayback();
    }
    @Override
    public void onBackPressed() {
        startActivity(new Intent(this,MainActivity.class));

    }


}
