package com.example.konstantin.dadad;

import android.content.Intent;
import android.content.SharedPreferences;
import android.support.constraint.ConstraintLayout;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.MotionEvent;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.RelativeLayout;

import butterknife.BindView;
import butterknife.ButterKnife;
import butterknife.OnClick;

import com.example.konstantin.dadad.joystick;

public class MainActivity extends AppCompatActivity {

    @BindView(R.id.buttonStream)
    Button buttonStream;

    @BindView(R.id.buttonTest)
            Button buttonTest;

    SharedPreferences prefs;

    String savedText;
    final String SAVED_TEXT="saved_text";

    EditText editTextIP;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        ButterKnife.bind(this);
        editTextIP=(EditText)findViewById(R.id.editText);

        loadtext();

    }

    private void saveText() {
        prefs=getPreferences(MODE_PRIVATE);
        SharedPreferences.Editor editor=prefs.edit();
        editor.putString(SAVED_TEXT,editTextIP.getText().toString());
        savedText=editTextIP.getText().toString();
        editor.commit();
    }

    private void loadtext() {
        prefs=getPreferences(MODE_PRIVATE);
        savedText = prefs.getString(SAVED_TEXT,"");
        editTextIP.setText(savedText);
    }

    @OnClick(R.id.buttonTest)
    public void OnClickTest() {
        startActivity(new Intent(this,test.class));
    }


    @OnClick(R.id.buttonStream)
    public void onClickStream() {
        saveText();
        if(!(savedText.toLowerCase().startsWith("http://") || savedText.toLowerCase().startsWith("https://")))
                savedText="http://"+savedText;
        startActivity(new Intent(this,StreamActivity.class).putExtra("ip",savedText));

    }

    @Override
    protected void onDestroy(){
        super.onDestroy();
        saveText();
    }

    @Override
    public void onBackPressed() {
        Intent intent = new Intent(Intent.ACTION_MAIN);
        intent.addCategory(Intent.CATEGORY_HOME);
        intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
        startActivity(intent);
    }


}
