package com.example.konstantin.dadad;

import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Point;
import android.os.Handler;
import android.os.Message;
import android.support.constraint.ConstraintLayout;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.MotionEvent;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.RelativeLayout;
import android.widget.TextView;

import butterknife.BindView;
import butterknife.ButterKnife;
import butterknife.OnClick;
import com.example.konstantin.dadad.DrivesControl;

import com.example.konstantin.dadad.joystick;

public class MainActivity extends AppCompatActivity {

    @BindView(R.id.buttonStream)
    Button buttonStream;

    SharedPreferences prefs;

    String savedText;
    final String SAVED_TEXT = "saved_text";

    String savedPort;
    final String SAVED_PORT = "saved_port";

    EditText editTextIP, editText2;
    EditText editTextPort;
    TextView textViewState, textViewRx;



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        ButterKnife.bind(this);
        editTextIP = (EditText) findViewById(R.id.editText);
        editTextPort = (EditText) findViewById(R.id.editTextPort);

        loadtext();

    }


    private void saveText() {
        prefs = getPreferences(MODE_PRIVATE);
        SharedPreferences.Editor editor = prefs.edit();
        editor.putString(SAVED_TEXT, editTextIP.getText().toString());
        editor.putString(SAVED_PORT,editTextPort.getText().toString());
        savedText = editTextIP.getText().toString();
        savedPort=editTextPort.getText().toString();
        editor.commit();
    }

    private void loadtext() {
        prefs = getPreferences(MODE_PRIVATE);
        savedText = prefs.getString(SAVED_TEXT, "");
        savedPort=prefs.getString(SAVED_PORT,"");
        editTextIP.setText(savedText);
        editTextPort.setText(savedPort);
    }

    @OnClick(R.id.buttonStream)
    public void onClickStream() {
        saveText();

        if (!(savedText.toLowerCase().startsWith("http://") || savedText.toLowerCase().startsWith("https://")))
            savedText = "http://" + savedText;
        startActivity(new Intent(this, StreamActivity.class)
                .putExtra("ip", savedText)
                .putExtra("ipdata",editTextIP.getText().toString())
                .putExtra("port",Integer.parseInt(editTextPort.getText().toString())));

    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        saveText();
    }

    @Override
    public void onBackPressed() {
        Intent intent = new Intent(Intent.ACTION_MAIN);
        intent.addCategory(Intent.CATEGORY_HOME);
        intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
        startActivity(intent);
    }

    }



