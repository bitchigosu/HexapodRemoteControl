package com.example.konstantin.dadad;

import android.util.Log;

/**
 * Created by Konstantin on 13.03.2018.
 */

public class DrivesControl {
    private double cStartAngle;
    private double cFemurOffset;
    private double fStartZOffset;
    private double fStartFarOffset;
    private double fLength;
    private double fStartAngle;
    private double tLenght;
    private double tStartAngle;

    private double cAngle,fAngle,tAngle;



    private Point3d cStart = new Point3d();


    public DrivesControl () {

    }
    void cfgCoxa(double cStartX,double cStartY,double cStartAngle,double cFemurOffset) {
        cStart.x=cStartX;
        cStart.y=cStartY;
        this.cStartAngle=cStartAngle;
        this.cFemurOffset=cFemurOffset;

    }

    void cfgFemur(double fStartZOffset,double fStartFarOffset,double fLength,double fStartAngle) {
        this.fStartZOffset=fStartZOffset;
        this.fStartFarOffset=fStartFarOffset;
        this.fLength=fLength;
        this.fStartAngle=fStartAngle;
    }

    void cfgTibia(double tLenght, double tStartAngle) {
        this.tLenght=tLenght;
        this.tStartAngle=tStartAngle;
    }

    void reach(Point3d dest) {
        double hDist =
                Math.sqrt(Math.pow(dest.x - cStart.x,2) + Math.pow(dest.y - cStart.y,2));
        double additionalCoxaAngle = hDist == 0.0 ? 0 : Math.asin(cFemurOffset/hDist);
        double primaryCoxaAngle = polarAngle(dest.x - cStart.x,dest.y-cStart.y);
        cAngle = hDist == 0.0 ? 0:primaryCoxaAngle-additionalCoxaAngle-cStartAngle;
        double localDestX=hDist <= cFemurOffset ?
                - fStartFarOffset : Math.sqrt(Math.pow(hDist,2) - Math.pow(cFemurOffset,2)) - fStartFarOffset;
        double localDestY=dest.z-fStartZOffset;
        double localDistPow=Math.pow(localDestX,2)+Math.pow(localDestY,2);
        if(localDistPow > Math.pow(fLength+tLenght,2)) {
            Log.i("BBBBBB","lol");
            return;
        }

        double A = -2 * localDestX;
        double B= -2*localDestY;
        double C=Math.pow(localDestX,2)+Math.pow(localDestY,2)+Math.pow(fLength,2)-Math.pow(tLenght,2);
        double X0=-A * C / (Math.pow(A,2)+Math.pow(B,2));
        double Y0=-B * C / (Math.pow(A,2)+Math.pow(B,2));
        double D=Math.sqrt(Math.pow(fLength,2)-(Math.pow(C,2)/(Math.pow(A,2)+Math.pow(B,2))));
        double mult = Math.sqrt(Math.pow(D,2)/(Math.pow(A,2)+Math.pow(B,2)));
        double ax, ay, bx, by;
        ax = X0 + B * mult;
        bx = X0 - B * mult;
        ay = Y0 - A * mult;
        by = Y0 + A * mult;

        double jointLocalX = (ax > bx) ? ax : bx;
        double jointLocalY = (ax > bx) ? ay : by;

        double primaryFemurAngle = polarAngle(jointLocalX, jointLocalY);
        fAngle = primaryFemurAngle - fStartAngle;

        double primaryTibiaAngle = polarAngle(localDestX - jointLocalX, localDestY - jointLocalY);
        tAngle = (primaryTibiaAngle - fAngle) - tStartAngle;
        Log.i("cAngle",String.valueOf(cAngle));
        Log.i("fAngle",String.valueOf(fAngle));
        Log.i("tAngle",String.valueOf(tAngle));

       // move(cAngle,fAngle,tAngle);
    }
    public double getAngles(String name) {
        switch (name) {
            case "cAngle": return cAngle;
            case "fAngle": return fAngle;
            case "tAngle": return tAngle;
        }
        return 0;
    }

    private double polarAngle(double x, double y) {
        if (x>0) return Math.atan(y/x);
        if (x<0 && y>=0) return Math.atan(y/x)+Math.PI;
        if (x<0 && y<0) return Math.atan(y/x)-Math.PI;
        if(y>0) return Math.PI/2;
        if (y<0) return Math.PI/-2;
        return 0;
    }

    public class Point3d {
       private double x,y,z;

       public Point3d() {
       }

       public Point3d(double x, double y, double z) {
           this.x = x;
           this.y = y;
           this.z = z;
       }

       public Point3d(double[] p) {
           x=p[0];
           y=p[1];
           z=p[2];
       }

       public void Point3dSum (double x, double y, double z) {
           this.x+=x;
           this.y+=y;
           this.z+=z;
       }

        public void Point3dMinus (double x, double y, double z) {
            this.x-=x;
            this.y-=y;
            this.z-=z;
        }

        public void Point3dMult (double m) {
            this.x*=m;
            this.y*=m;
            this.z*=m;
        }

        public void Point3dDiv (double m) {
            this.x/=m;
            this.y/=m;
            this.z/=m;
        }

    }
}
